# FitTrack

Offline fitness and nutrition tracker.

## Included
- Account registration/login/logout on the device
- Separate data per account
- Daily calories, protein, carbs, fat and water tracking
- Indian food database with roti, saag, dal, rice, paneer, etc.
- Custom food entries
- Automatic workout calorie estimate using body weight, exercise type and minutes
- Editable workout calories
- Weight tracking, BMI, progress and daily activity
- Dark mode and JSON backup/restore
- FitTrack branding and developer contact

Build with Gradle 8.7 + Java 17.
