#!/usr/bin/env bash
set -e
ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT"
if command -v gradle >/dev/null 2>&1; then
  gradle assembleDebug
else
  echo "Gradle is required. On GitHub Actions use the included workflow to install Gradle."
  exit 1
fi
cp app/build/outputs/apk/debug/app-debug.apk FitTrack.apk
